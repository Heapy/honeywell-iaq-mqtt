
package com.honeywell.lib.utils;

public class DebugUtil {
    public static boolean DEBUG = true;
}