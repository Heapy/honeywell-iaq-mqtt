package com.honeywell.iaq.events;

/**
 * Created by zhujunyu on 2017/5/3.
 */

public class IAQGetDataFromWsEvent extends IAQEvents {

    public IAQGetDataFromWsEvent() {
    }
}
