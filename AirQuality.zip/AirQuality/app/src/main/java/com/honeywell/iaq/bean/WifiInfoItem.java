package com.honeywell.iaq.bean;

public class WifiInfoItem {
    public String SSID;

    public String BSSID;

    public int imageid;

    public int frequency;

    public int dmb;

    public String security;

    public boolean isConnected = false;

    public String ipaddress;

}
