package com.honeywell.iaq.events;

/**
 * Created by milton_lin on 17/1/24.
 */

public class IAQEnvironmentChartEvent extends IAQEvents {

}
