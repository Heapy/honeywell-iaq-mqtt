package com.honeywell.iaq.interfaces;

public interface IData {

}
