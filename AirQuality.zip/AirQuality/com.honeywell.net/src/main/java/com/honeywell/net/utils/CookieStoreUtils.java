package com.honeywell.net.utils;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by zhujunyu on 2017/3/13.
 */

public class CookieStoreUtils {

    public static void setSharedPreferencesValue(Context context, String key, String value) {
//        Context context1 = Application.
//        SharedPreferences settings = Appcontext.getSharedPreferences("IAQ", 0);
//        SharedPreferences.Editor editor = settings.edit();
//        editor.putString(key, value);
//        editor.apply();
    }

}
